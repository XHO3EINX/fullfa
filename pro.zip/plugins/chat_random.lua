--by : @xx_a_l_i_xx
-- :)
local function run(msg, matches)
if matches[1] == "بای" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'بای','خدافز','خدانگهدار','برو دیگگههه😒','ای دون برو به سلامت','بابای عشقم','خدافز به بابا هم سلام برسون','بای بای','bb azizam'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "خدافظ" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'بای','خدافز','خدانگهدار','برو دیگگههه😒','ای دون برو به سلامت','بابای عشقم','خدافز به بابا هم سلام برسون','بای بای','bb azizam'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "عزیزم" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'bale nafasam','bale eshqam','bale zendegim','voice befrest'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "خوبی" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'ممنون','تشکر','به خوبی شما','عالی','مرسی نفسم','مرسی عشقم','من خوبم.خانواده خوبن؟','مرسی اه','khobam❤️'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "خوبین" then
      if msg.to.type == 'channel' then
            local answers = {'ممنون','تشکر','به خوبی شما','عالی','مرسی نفسم','مرسی عشقم','من خوبم.خانواده خوبن؟','مرسی اه','khobam❤️'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😐" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'😐عجب','😐خخخ بسه','مرگ من بسه','جون عمت نفرست','نفرست اههه','پوووووف','داری روانیم میکنیاااا','مرسی اه','نفرست دیگ بسه ','هه هه مسخره همش پوکر میده','بفرست تا جونت در بیاد','الان که چی پوکر میدی','خیلی زیاد میفرستی','وای تو شاه پوکری که '}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "شب بخیر" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'همچنین','تشکر','مرسی ممنون','شب بخیر','شب خوبی داشته باشید','شب خوبی برای شما ارزومندم','خدانگهدار گرامی','یاعلی برادر','#GN'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "اصل" then
     if msg.to.type == 'channel' or 'chat' then
            local answers = {'mn asl nmidam','asl? omran aval to','bazam asl nmidoam goftam k','fekresham nkn asl nmidam'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == 'سلام' then
			if msg.to.type == 'channel' or 'chat' then
            local answers = {'سلام خوبی؟','سلام عشقم','سلام','سلام جیگر گروه','سلام گلم','چند بار سلام میکنی','سلام خخخخ','😐سلام','سهلام 😐😐','درود دوست عزیز'}
            return answers[math.random(#answers)]
			end
	  end
	  if matches[1] == "شروع" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'spamer 500 !boobs'}
            return answers[math.random(#answers)]
      end
	  end
	  	  if matches[1] == "اسپمر" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'spamer 500 t.me/senior_Amin'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "عکس" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'mn aks nmidam aval to','to aval aks bede','mn aks nmidaaaaaaaaaaaam ro profilam aksam hast'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "لینک" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'لینک برای چیته اخه','لینک کجا رو میخوای','لینک گروهو میخوای؟','لینک نداریم برو','میگم نداریم عه','الان دقیقا لینک اینجا رو میخوای؟','لینک برا چیته کلک','باید وایسی مدیر بیاد','خخخ لینک کجا بود'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "اره" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'hey khoda che donyaeye :('}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "کیر" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'بی ادب','بی فرهنگ','بی شعور','خاک بر سرت کنن','احمق بی ادب','فرهنگ داشته باش','به اندازه نخود مغز نداری فوش میدی','بی نزاکت','واقعا خیلی بده کارت به جایی رسیده ربات تحقیرت کنه'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "کس" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'بی ادب','بی فرهنگ','بی شعور','خاک بر سرت کنن','احمق بی ادب','فرهنگ داشته باش','به اندازه نخود مغز نداری فوش میدی','بی نزاکت','واقعا خیلی بده کارت به جایی رسیده ربات تحقیرت کنه'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "کون" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'بی ادب','بی فرهنگ','بی شعور','خاک بر سرت کنن','احمق بی ادب','فرهنگ داشته باش','به اندازه نخود مغز نداری فوش میدی','بی نزاکت','واقعا خیلی بده کارت به جایی رسیده ربات تحقیرت کنه'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "ویس" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'aval to voice bede',' aval u'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "رویا" then
     if msg.to.type == 'channel' or 'chat' then
            local answers = {'bale asssisam','jonam eshqam','jonam zendegim','Wooooow bale nikotinnn man'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "عشقم" then
      if msg.to.type == 'channel' or 'chat' then
            local answers = {'bale asisam','bale eshqam','jonam asisam'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "pv" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'pv???','پی وی حرامه','شما بیا پی وی من کارت دارم','یکی هم بیاد پی وی ما','پی وی خز شد اه ','برید پی ویش تا خودشو نکشته','همش پی وی پی وی پس کی تو گروهه','پی وی شکلات میدن انقدر میرید؟','یکی بیاد پی وی من یه آدامس دارم آهنگ میخونه'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "پی وی" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'pv???','پی وی حرامه','شما بیا پی وی من کارت دارم','یکی هم بیاد پی وی ما','پی وی خز شد اه ','برید پی ویش تا خودشو نکشته','همش پی وی پی وی پس کی تو گروهه','پی وی شکلات میدن انقدر میرید؟','یکی بیاد پی وی من یه آدامس دارم آهنگ میخونه'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "پیوی" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'pv???','پی وی حرامه','شما بیا پی وی من کارت دارم','یکی هم بیاد پی وی ما','پی وی خز شد اه ','برید پی ویش تا خودشو نکشته','همش پی وی پی وی پس کی تو گروهه','پی وی شکلات میدن انقدر میرید؟','یکی بیاد پی وی من یه آدامس دارم آهنگ میخونه'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😂" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'😂😂😂','وای دلم😂','شما چقد خوش خنده ای عشقم😂','جوون تو فقط بخند 😂😂','اه بسه دیگه چقد میخندی','یکی اینو ببره تا از خنده غش نکرده😂','اوووف عاشق خنده هاتم😂','جدی بسه😂','خنده هات خیلی زیباست عشقم😂😂','لطقا تمومش کن','دیشب تو دریاچه نکن بودی انگار','بسه دیگه','کافیه برای چی میخندی','مسخره بازیا رو تموم کن','مسخره کردی منو؟'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "به تو چه" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'به من همه چه','چرا اخه😔','دوست دارم بدونم خو','حرف آخرته دیگه؟','چراا اخه نمیگی بم','حالا من شدم غریبه دیگه','باشه نگو','نخواستم اصلا'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "ویس" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'ویس دوس داری عشقم؟','اره اره ویس بفرست میخوام','صداتو عشقه','الان ویس میخوای؟','منم صدام خوبه ها ویس بدم؟','بیا پی ویس ویس بازی کنیم','یه ویس بفرست پی وی','جوون ویس'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "دوست" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'منم دوست دارم','میسی عشقم😍','نفسمی😚','مرسی عزیزم','بیا پی وی رل بزنیم عشقم😍😂','عاشقتم که🙊','شما بیا پی وی کارت دارم😉','مرسی زیبایی زندگیم💐❤️'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😔" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'😔ناراحت نباش','گریه کن خالی شی عشقم','😔گریه نکن اشک درومد','بیا پی وی بت آرامش بدم','نمیای پی وی؟','اوووف هم ناراحتی','ناراحت نشو عزیزم','بیخیال ناراحت نباش'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "سوال" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'سوال بپرسم؟','کلاس چندم عمویی','سوال میکنم جواب میدی؟','سوالت چرت بود','نمیای پی وی؟','مسخره با این سوالات','سوال داری بپرس','اگه بلد باشم جواب میدم'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "جواب" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'جواب بدم؟','حتما باید بگم؟','نمیشه نگم؟','نمیگم','نمیای پی وی؟','جوابت مسخره بوداا','خیلی چرتی خخخ','عجب پاسخی'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "تمام" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'چییییی؟','چی تمام کردی؟','تمام نکن','تو نمیتونی این کارو با من بکنی','چی تمام؟','اوخیی','بمیرم برات','خیلی ناراحت شدم'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "👍" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'👍','لایک به وجودت','لایک داشت','ایول','لایک به خودت گلم','جووونز لایک کرد','بمیری برام خخخ','لایک تقدیم به تو'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "لایک" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'👍','لایک به وجودت','لایک داشت','ایول','لایک به خودت گلم','جووونز لایک کرد','بمیری برام خخخ','لایک تقدیم به تو'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "خبر" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'خبر؟؟','چی شده','عه نگوووو','چه خبره','واقعا؟','خبرا زیاده','تو چه خبر','خبر چی اخه','مگه من اخبارم اخه','به من چه'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "علی" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'وایی عشقم بابام','با بابام کاری داری؟','عشق منهه که','دوست دارم بابایی','بابایی بیا کارت دارن','واییی باباییییی','بوج برای بابام'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😘" then
     if msg.to.type == 'channel' or 'chat' then
           local answers = {'😘😘','اووووف بوسم کرد','واییی تو گروه عشقم نکن','بیا پی وی عشقم','واهاییی','بوسه های زیباتو دوست دارم','بوووووووووووووج'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "بگو" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'نمیگم','چرا بگم','مگه تو کی هستی به حرفت گوش بدم','نمیگم به تو هم ربطی نداره ','تو بگو ببینم بلدی','بگم؟','گمجو نمیگم بت'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "عاشقتم" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'me 2','me too','manam hamintor asisam','I love you too'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "ممنون" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'خ����اهش ��یکنم','وظیفست قربان','مرضو ممنون','هههههه ممنون که چی شد حالا گفتی','نیازی به تشکر تو ندارم','خودتو خر کن','خواهش'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "کلش" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'clash chiye?','man clash nadaram ke'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "چطوری" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'khobam assisam','khobam eshqaAAM','khobam avazi','khobam nafasam','na delam gerfte',' hey khoda che donyaeye :('}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "خودتی" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'jakesh koni','بی شرف بی ادب','khodaya ino shefa bede lotfan :D Mrc'}
            return answers[math.random(#answers)]
      end
	  end
	  if matches[1] == "😕" then
     if msg.to.type == 'channel' or 'chat' then
           local answers = {'😕😕','چه مرگته تو','بمیر اصلا','مرسییی اه','گمجو به نظرم','دهنت چرا همیشه کجه تو؟','چته الان دقیقا','مشکلت چیه کسخل'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "خفه شو" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'خودت خفه شو','دلت میاد خفه بشم؟','خیلی بی رحمی','الان دقیقا میخوای چکار کنم؟','نمیشم','حتما بشم؟','تا 3 بشمار خفه بشم','نمیشم کسخل مالیاتی'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "گمشو" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'بی ادب','کجا گم شم؟','آدرسو بلدم گم نمیشم','خودت گمشو','بی شول','به نظرم بگو گمجو خوشمل تره','اگه نرم میخوای چه غلطی بکنی مثلا','چته الان دقیقا','چکارم داری توووو عه'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "سیک" then
     if msg.to.type == 'channel' or 'chat' then
           local answers = {'بی ادب','تیرشو یادت رفت','حضوری بیا بگامت بچه پرو','گمشو بابا جقی','خودت سیک کن کیری فیس','برو جقتو بزن','اگه نرم میخوای چه غلطی بکنی مثلا','چته الان دقیقا','خخخخخ بسیک باو'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "جاکش" then
      if msg.to.type == 'channel' or 'chat' then
           local answers = {'nago bi adab','nago bi tarbiyat','khodeti avazi','fosh nade'}
            return answers[math.random(#answers)]
      end
	   end
	  if matches[1] == "جون" then
     if msg.to.type == 'channel' or 'chat' then
           local answers = {'hichi nago bw','to kiey adam shodi nadidamet','ههههههههههههههههههههه'}
            return answers[math.random(#answers)]
      end
    end
end
return {
  description = "Chat With Robot Server", 
  usage = "chat with robot",
  patterns = {
    "^بای$",
	 "^خدافظ$",
	"^عزیزم$",
	"^خوبی$",
	"^خوبین$",
	"^😐$",
	"^شب بخیر$",
	"اصل",
	"^سلام$",
	"شروع",
	"اسپمر",
	"عکس",
	"لینک",
	"اره",
	"کیر",
	"کس",
	"کون",
	"ویس",
	"رویا",
	"عشقم",
	"pv",
	"پی وی",
	"پیوی",
	"😂",
	"به تو چه",
	"ویس",
	"دوست",
	"😔",
	"سوال",
	"جواب",
	"تمام",
	"👍",
	"لایک",
	"خبر",
	"😘",
	"بگو",
	"عاشقتم",
	"ممنون",
	"کلش",
	"چطوری",
	"خودتی",
	"😕",
	"خفه شو",
	"گمشو",
	"سیک",
	"جاکش",
	"جون",
    }, 
  run = run
}

