do local _ = {
  about_text = "",
  enabled_plugins = {
    "admin",
    "anti_spam",
	"chat_random",
	"cp",
    "arabic_lock",
    "banhammer",
    "block",
    "broadcast",
    "buy",
    "cleanall",
    "expire",
    "filter",
    "help",
    "inpm",
    "inrealm",
    "lock_bots",
    "msg_checks",
    "invite",
    "whitelist",
    "plugins",
    "rmsg",
    "setbye",
    "setwlc",
    "supergroups",
    "time",
    "saveplug",
    "sendplug",
    "on-off",
    "idme",
    "dlpl",
    "clean_delete_ac",
    "chat",
    "note"
  },
  help_text = "",
  help_text_realm = "",
  help_text_super = "",
  moderation = {
    data = "data/moderation.json"
  },
  sudo_users = {
    234724442,
    301278951,
	300131107,
    0
  }
}
return _
end